NoSqL_Hadoop_Lab-1

This Lab consists of Map Reduce programs on Hadoop. Performed on a single node.

Question 1: Input file has the data of weather of last few years and mapreduced returns the yearly maximum temperature record.

Question 2: Input file consists of web access log produced by a web server and the Map Reduce program counts the number of times GIF, JPG, and other image files that have been accessed by clients.

Question 3: Input file consists of web access log produced by a web server and the the Map Reduce program outputs Total number of requests and Total download size on Monthly basis.

Question 4: Input file consists of web access log produced by a web server and the the Map Reduce program lists Timestamp, URL for which http response status has been 404.
